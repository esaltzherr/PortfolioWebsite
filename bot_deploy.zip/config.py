import os
from pathlib import Path
from dotenv import load_dotenv

for _p in [Path.cwd() / ".env", Path(__file__).parent / ".env", Path.home() / "bot" / ".env"]:
    if _p.exists():
        load_dotenv(_p, override=False)

ALPACA_API_KEY = os.getenv("ALPACA_API_KEY") or os.getenv("APCA_API_KEY_ID")
ALPACA_SECRET_KEY = os.getenv("ALPACA_SECRET_KEY") or os.getenv("APCA_API_SECRET_KEY")

if not ALPACA_API_KEY or not ALPACA_SECRET_KEY:
    raise ValueError("Missing ALPACA_API_KEY / APCA_API_KEY_ID or ALPACA_SECRET_KEY / APCA_API_SECRET_KEY in .env")