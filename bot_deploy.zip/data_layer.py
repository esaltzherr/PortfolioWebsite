"""
data_layer.py

Handles all Alpaca data fetching with:
  - SIP -> IEX feed fallback
  - Threaded parallel chunk fetching (ThreadPoolExecutor)
  - Parquet disk cache — re-runs skip the API entirely

Cache files live in ./cache/ keyed by MD5 of request params.
Delete the cache folder to force a full re-fetch.

Public functions:
  get_stock_universe()   -> DataFrame of tradable US equities
  get_daily_bars()       -> daily OHLCV
  get_15min_bars()       -> 15-minute OHLCV (used for 15M and 30M entry prices)
  get_hourly_bars()      -> 1-hour OHLCV (used for 1H entry price)
  get_intraday_bars()    -> single-symbol intraday (used by Streamlit app)
"""

import hashlib
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from typing import List

import pandas as pd
from dotenv import load_dotenv

from alpaca.data.historical.stock import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest
from alpaca.data.timeframe import TimeFrame, TimeFrameUnit
from alpaca.trading.client import TradingClient

load_dotenv()

API_KEY    = os.getenv("APCA_API_KEY_ID")
API_SECRET = os.getenv("APCA_API_SECRET_KEY")

if not API_KEY or not API_SECRET:
    raise ValueError("Missing Alpaca API credentials in .env")

data_client    = StockHistoricalDataClient(API_KEY, API_SECRET)
trading_client = TradingClient(API_KEY, API_SECRET, paper=True)

CACHE_DIR      = "cache"
MAX_WORKERS    = 6
RETRY_ATTEMPTS = 3
RETRY_DELAY    = 2.0


# ── Cache helpers ──────────────────────────────────────────────────────────────

def _cache_key(prefix: str, symbols: list, start_dt: datetime,
               end_dt: datetime, tf: str) -> str:
    raw = f"{prefix}|{'|'.join(sorted(symbols))}|{start_dt}|{end_dt}|{tf}"
    return hashlib.md5(raw.encode()).hexdigest()


def _cache_path(key: str) -> str:
    os.makedirs(CACHE_DIR, exist_ok=True)
    return os.path.join(CACHE_DIR, f"{key}.parquet")


def _load_cache(key: str) -> pd.DataFrame | None:
    path = _cache_path(key)
    if os.path.exists(path):
        return pd.read_parquet(path)
    return None


def _save_cache(key: str, df: pd.DataFrame) -> None:
    df.to_parquet(_cache_path(key), index=False)


# ── Low-level fetch ────────────────────────────────────────────────────────────

def _fetch_chunk(symbols: list, timeframe, start_dt: datetime,
                 end_dt: datetime) -> pd.DataFrame:
    """One chunk with SIP→IEX fallback and retries."""
    last_error = None
    for feed in ["iex", "sip"]:
        for attempt in range(RETRY_ATTEMPTS):
            try:
                req = StockBarsRequest(
                    symbol_or_symbols=symbols,
                    timeframe=timeframe,
                    start=start_dt,
                    end=end_dt,
                    adjustment="split",
                    feed=feed,
                )
                barset = data_client.get_stock_bars(req)
                df = barset.df.reset_index()
                if not df.empty:
                    df["feed_used"] = feed
                return df
            except Exception as e:
                last_error = e
                if attempt < RETRY_ATTEMPTS - 1:
                    time.sleep(RETRY_DELAY)
    if last_error:
        raise last_error
    return pd.DataFrame()


def _fetch_all_chunks(symbols: list, timeframe, start_dt: datetime,
                      end_dt: datetime, chunk_size: int, label: str) -> pd.DataFrame:
    """Parallel threaded fetch across all chunks."""
    chunks  = [symbols[i:i + chunk_size] for i in range(0, len(symbols), chunk_size)]
    total   = len(chunks)
    results = {}
    errors  = []

    print(f"  [{label}] {len(symbols):,} symbols / {total} chunks / {MAX_WORKERS} threads...")

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {
            executor.submit(_fetch_chunk, chunk, timeframe, start_dt, end_dt): idx
            for idx, chunk in enumerate(chunks)
        }
        done = 0
        for future in as_completed(futures):
            idx = futures[future]
            done += 1
            try:
                df = future.result()
                if not df.empty:
                    results[idx] = df
            except Exception as e:
                errors.append((idx, str(e)))
            if done % 10 == 0 or done == total:
                print(f"  [{label}] {done}/{total} chunks done"
                      + (f"  ({len(errors)} errors)" if errors else ""))

    if errors:
        print(f"  [{label}] WARNING: {len(errors)} chunks failed")
    if not results:
        return pd.DataFrame()
    return pd.concat(results.values(), ignore_index=True)


# ── Shared post-processing for intraday bars ──────────────────────────────────

def _add_et_time_cols(df: pd.DataFrame) -> pd.DataFrame:
    """Add date/hour_et/minute_et columns in Eastern time."""
    et = df["timestamp"].dt.tz_convert("America/New_York")
    df["date"]      = et.dt.date
    df["hour_et"]   = et.dt.hour
    df["minute_et"] = et.dt.minute
    return df


def _normalise_dates(df: pd.DataFrame) -> pd.DataFrame:
    """Force date column to datetime.date (survives parquet round-trips)."""
    df["date"] = pd.to_datetime(df["date"]).dt.date
    return df


# ── Public API ─────────────────────────────────────────────────────────────────

def get_stock_universe(include_etfs: bool = True) -> pd.DataFrame:
    assets = trading_client.get_all_assets()
    rows   = []
    for a in assets:
        if getattr(a, "asset_class", None) != "us_equity":
            continue
        if getattr(a, "status", None) != "active":
            continue
        if not getattr(a, "tradable", False):
            continue
        symbol = getattr(a, "symbol", None)
        if not symbol:
            continue
        rows.append({
            "symbol":       symbol,
            "name":         getattr(a, "name", None),
            "exchange":     str(getattr(a, "exchange", "") or ""),
            "fractionable": getattr(a, "fractionable", None),
        })
    df = pd.DataFrame(rows).drop_duplicates(subset=["symbol"]).reset_index(drop=True)
    if not include_etfs:
        df = df[~df["name"].fillna("").str.contains("ETF", case=False)].copy()
    return df.reset_index(drop=True)


def get_daily_bars(symbols: List[str], start_dt: datetime, end_dt: datetime,
                   chunk_size: int = 200, use_cache: bool = True) -> pd.DataFrame:
    """Daily OHLCV bars with cache + threading."""
    key = _cache_key("daily", symbols, start_dt, end_dt, "1D")
    if use_cache:
        cached = _load_cache(key)
        if cached is not None:
            print(f"  [daily] Loaded {len(cached):,} rows from cache")
            return _normalise_dates(cached)

    df = _fetch_all_chunks(symbols, TimeFrame.Day, start_dt, end_dt, chunk_size, "daily")
    if df.empty:
        return df

    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["date"]      = df["timestamp"].dt.date
    df = df.sort_values(["symbol", "timestamp"]).reset_index(drop=True)

    if use_cache:
        _save_cache(key, df)
        print(f"  [daily] Cached {len(df):,} rows")
    return df


def get_15min_bars(symbols: List[str], start_dt: datetime, end_dt: datetime,
                   chunk_size: int = 75, use_cache: bool = True) -> pd.DataFrame:
    """
    15-minute OHLCV bars with cache + threading.

    Bar timestamps are bar-open times (Alpaca convention):
      9:30 bar  open=9:30  close=9:45   -> use close for 15M entry price
      9:45 bar  open=9:45  close=10:00  -> use close for 30M entry price

    Adds columns: date, hour_et, minute_et
    """
    key = _cache_key("15min", symbols, start_dt, end_dt, "15M")
    if use_cache:
        cached = _load_cache(key)
        if cached is not None:
            cached = _normalise_dates(cached)
            print(f"  [15min] Loaded {len(cached):,} rows from cache")
            return cached

    tf = TimeFrame(15, TimeFrameUnit.Minute)
    df = _fetch_all_chunks(symbols, tf, start_dt, end_dt, chunk_size, "15min")
    if df.empty:
        return df

    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = _add_et_time_cols(df)
    df = df.sort_values(["symbol", "timestamp"]).reset_index(drop=True)

    if use_cache:
        _save_cache(key, df)
        print(f"  [15min] Cached {len(df):,} rows")
    return df


def get_hourly_bars(symbols: List[str], start_dt: datetime, end_dt: datetime,
                    chunk_size: int = 100, use_cache: bool = True) -> pd.DataFrame:
    """
    1-hour OHLCV bars with cache + threading.

    9:30 bar covers 9:30–10:30 AM. Its CLOSE = 10:30 AM price (1H entry).
    Adds columns: date, hour_et, minute_et
    """
    key = _cache_key("hourly", symbols, start_dt, end_dt, "1H")
    if use_cache:
        cached = _load_cache(key)
        if cached is not None:
            cached = _normalise_dates(cached)
            print(f"  [hourly] Loaded {len(cached):,} rows from cache")
            return cached

    tf = TimeFrame(1, TimeFrameUnit.Hour)
    df = _fetch_all_chunks(symbols, tf, start_dt, end_dt, chunk_size, "hourly")
    if df.empty:
        return df

    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    df = _add_et_time_cols(df)
    df = df.sort_values(["symbol", "timestamp"]).reset_index(drop=True)

    if use_cache:
        _save_cache(key, df)
        print(f"  [hourly] Cached {len(df):,} rows")
    return df


def get_intraday_bars(symbol: str, selected_date: datetime,
                      timeframe_minutes: int = 5) -> pd.DataFrame:
    """Single-symbol intraday bars (Streamlit app helper)."""
    start_dt = selected_date.replace(
        hour=0, minute=0, second=0, microsecond=0, tzinfo=timezone.utc)
    end_dt = start_dt + timedelta(days=1)
    df = _fetch_chunk([symbol], TimeFrame(timeframe_minutes, TimeFrameUnit.Minute),
                      start_dt, end_dt)
    if df.empty:
        return df
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    return df.sort_values("timestamp").reset_index(drop=True)
