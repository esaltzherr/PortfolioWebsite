"""
eod_report.py

Generates a detailed end-of-day recap after market close.
Prints a formatted summary to stdout AND writes a dated markdown file
to ./reports/YYYY-MM-DD.md

Compares live P&L vs the historical sim for the same date (if sim CSVs exist).

Usage:
  python eod_report.py                    # recap for today
  python eod_report.py --date 2025-06-10  # recap for a specific date
  python eod_report.py --all              # recap for every day in the DB

The live_trader.py calls this automatically at EOD, but you can also
run it standalone any time after market close.
"""

import argparse
import os
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import pandas as pd

import tracker

ET = ZoneInfo("America/New_York")
REPORTS_DIR = "reports"
SIM_DAILY_DIR = "results"   # where main.py wrote sim_*_daily.csv files

STRATEGY_LABELS = [
    "INTRADAY_OPEN_PRIOR_ret_1m_TOP_SHORT",
    "GAP_BOTTOM_LONG",
    "INTRADAY_15M_SIGNAL_TOP_SHORT",
    "INTRADAY_30M_SIGNAL_TOP_SHORT",
    "INTRADAY_30M_PRIOR_ret_6m_BOTTOM_LONG",
]

DIVIDER     = "=" * 68
SUBDIV      = "-" * 68
THIN        = "·" * 68


def _pnl_str(v, width=10) -> str:
    if v is None:
        return " " * width
    sign = "+" if v >= 0 else ""
    return f"{sign}{v:,.2f}".rjust(width)


def _pct_str(v, width=8) -> str:
    if v is None:
        return " " * width
    sign = "+" if v >= 0 else ""
    return f"{sign}{v:.2f}%".rjust(width)


def _load_sim_pnl_for_date(strategy: str, target_date: date) -> float | None:
    """
    Look for results/sim_{strategy}_daily.csv and return the day's equity
    change for target_date if it exists.
    """
    path = os.path.join(SIM_DAILY_DIR, f"sim_{strategy}_daily.csv")
    if not os.path.exists(path):
        return None
    try:
        df = pd.read_csv(path, parse_dates=["date"])
        df["date"] = pd.to_datetime(df["date"]).dt.date
        row = df[df["date"] == target_date]
        if row.empty:
            return None
        if "day_pnl_dollars" in df.columns:
            return float(row["day_pnl_dollars"].iloc[0])
        # Fallback: compute from equity diff
        idx = df[df["date"] == target_date].index[0]
        if idx == 0:
            return None
        prev_eq = df.loc[idx - 1, "equity"]
        this_eq = df.loc[idx,     "equity"]
        return float(this_eq - prev_eq)
    except Exception:
        return None


def build_recap(target_date: date) -> str:
    """Build the full EOD recap string for a given date."""
    date_str = str(target_date)

    # Fetch from DB
    daily   = tracker.get_daily_pnl(days=9999)
    daily   = [r for r in daily if r["trade_date"] == date_str]
    trades  = tracker.get_trades(days=9999)
    trades  = [t for t in trades if t.get("close_date") == date_str]
    eq_rows = tracker.get_daily_equity(days=9999)
    eq_snap = next((e for e in eq_rows if e["trade_date"] == date_str), None)

    lines = []
    lines.append(DIVIDER)
    lines.append(f"  END-OF-DAY RECAP   {target_date.strftime('%A, %B %d, %Y')}")
    lines.append(DIVIDER)

    # ── Account summary ───────────────────────────────────────────────────────
    if eq_snap:
        start = eq_snap.get("equity_start")
        end   = eq_snap.get("equity_end")
        pnl   = eq_snap.get("day_pnl")
        pct   = eq_snap.get("day_pnl_pct")
        lines.append(f"\n  ACCOUNT")
        lines.append(THIN)
        lines.append(f"  Equity start : ${start:>12,.2f}" if start else "  Equity start : —")
        lines.append(f"  Equity end   : ${end:>12,.2f}"   if end   else "  Equity end   : —")
        lines.append(f"  Day P&L      : {_pnl_str(pnl, 13)}  {_pct_str(pct)}")
    else:
        lines.append("\n  (No account equity snapshot for this date)")

    # ── Per-strategy table ────────────────────────────────────────────────────
    lines.append(f"\n  BY STRATEGY")
    lines.append(THIN)
    header = (f"  {'Strategy':<45} {'Trades':>6} {'Wins':>5} "
              f"{'WinRate':>8} {'P&L $':>10} {'Sim P&L $':>10}")
    lines.append(header)
    lines.append(SUBDIV)

    total_live_pnl = 0.0
    total_sim_pnl  = 0.0

    strats_to_show = [r["strategy"] for r in daily] if daily else STRATEGY_LABELS
    for strat in strats_to_show:
        row = next((r for r in daily if r["strategy"] == strat), None)
        sim_pnl = _load_sim_pnl_for_date(strat, target_date)

        if row:
            pnl      = row["gross_pnl"] or 0
            n_trades = row["n_trades"]  or 0
            n_wins   = row["n_wins"]    or 0
            win_rate = row["win_rate"]
            total_live_pnl += pnl
        else:
            pnl = n_trades = n_wins = 0
            win_rate = None

        if sim_pnl:
            total_sim_pnl += sim_pnl

        sim_str  = f"${sim_pnl:>+9,.2f}" if sim_pnl is not None else "    n/a   "
        pnl_str  = f"${pnl:>+9,.2f}"
        wr_str   = f"{win_rate:.0f}%" if win_rate is not None else "  —"
        short_name = strat[-42:] if len(strat) > 42 else strat

        lines.append(f"  {short_name:<45} {n_trades:>6} {n_wins:>5} "
                     f"{wr_str:>8} {pnl_str:>10} {sim_str:>10}")

    lines.append(SUBDIV)
    sim_total_str = f"${total_sim_pnl:>+9,.2f}" if total_sim_pnl else "    n/a   "
    lines.append(f"  {'TOTAL':<45} {'':>6} {'':>5} {'':>8} "
                 f"${total_live_pnl:>+9,.2f} {sim_total_str:>10}")

    # ── Trade detail per strategy ─────────────────────────────────────────────
    lines.append(f"\n\n  TRADE DETAIL")
    lines.append(THIN)

    for strat in STRATEGY_LABELS:
        strat_trades = [t for t in trades if t["strategy"] == strat]
        if not strat_trades:
            continue

        lines.append(f"\n  [{strat}]")
        lines.append(f"  {'Symbol':<8} {'Dir':<6} {'Entry':>8} {'Exit':>8} "
                     f"{'Shares':>9} {'P&L $':>9} {'P&L %':>7}")

        strat_trades_sorted = sorted(
            strat_trades,
            key=lambda x: x.get("pnl_dollars") or 0,
            reverse=True,
        )
        for t in strat_trades_sorted:
            pnl  = t.get("pnl_dollars") or 0
            ppct = t.get("pnl_pct") or 0
            ep   = t.get("open_price")  or 0
            xp   = t.get("close_price") or 0
            sh   = t.get("open_shares") or 0
            lines.append(
                f"  {t['symbol']:<8} {t['direction']:<6} "
                f"${ep:>7.2f} ${xp:>7.2f} "
                f"{sh:>9.3f} ${pnl:>+8.2f} {ppct:>+6.2f}%"
            )

    # ── Top / bottom 5 ───────────────────────────────────────────────────────
    all_closed = [t for t in trades if t.get("pnl_dollars") is not None]
    if all_closed:
        sorted_t = sorted(all_closed, key=lambda x: x["pnl_dollars"], reverse=True)
        lines.append(f"\n\n  BEST TRADES TODAY")
        lines.append(THIN)
        for t in sorted_t[:5]:
            lines.append(f"  {t['symbol']:<6} {t['strategy'][-35:]:<35}  "
                         f"${t['pnl_dollars']:>+8.2f}  ({t['pnl_pct']:>+.2f}%)")

        lines.append(f"\n  WORST TRADES TODAY")
        lines.append(THIN)
        for t in sorted_t[-5:][::-1]:
            lines.append(f"  {t['symbol']:<6} {t['strategy'][-35:]:<35}  "
                         f"${t['pnl_dollars']:>+8.2f}  ({t['pnl_pct']:>+.2f}%)")

    # ── Live vs sim comparison ────────────────────────────────────────────────
    if total_sim_pnl:
        diff    = total_live_pnl - total_sim_pnl
        lines.append(f"\n\n  LIVE vs SIM COMPARISON")
        lines.append(THIN)
        lines.append(f"  Live P&L : ${total_live_pnl:>+10,.2f}")
        lines.append(f"  Sim P&L  : ${total_sim_pnl:>+10,.2f}")
        lines.append(f"  Delta    : ${diff:>+10,.2f}  "
                     f"({'live beat sim' if diff >= 0 else 'sim beat live'})")

    lines.append(f"\n{DIVIDER}\n")
    return "\n".join(lines)


def save_report(target_date: date, content: str) -> str:
    os.makedirs(REPORTS_DIR, exist_ok=True)
    path = os.path.join(REPORTS_DIR, f"{target_date}.md")
    with open(path, "w") as f:
        f.write("```\n")
        f.write(content)
        f.write("```\n")
    return path


def run_recap(target_date: date, save: bool = True):
    content = build_recap(target_date)
    print(content)
    if save:
        path = save_report(target_date, content)
        print(f"  Report saved → {path}")
    return content


def main():
    parser = argparse.ArgumentParser(description="EOD recap generator")
    parser.add_argument("--date", type=str, default=None,
                        help="Date to recap (YYYY-MM-DD). Default: today.")
    parser.add_argument("--all", action="store_true",
                        help="Generate recap for every date in the DB.")
    parser.add_argument("--no-save", action="store_true",
                        help="Print only, don't write .md file.")
    args = parser.parse_args()

    tracker.init_db()

    if args.all:
        daily_rows = tracker.get_daily_pnl(days=9999)
        dates = sorted(set(r["trade_date"] for r in daily_rows))
        for d_str in dates:
            run_recap(date.fromisoformat(d_str), save=not args.no_save)
        return

    target = date.fromisoformat(args.date) if args.date else date.today()
    run_recap(target, save=not args.no_save)


if __name__ == "__main__":
    main()