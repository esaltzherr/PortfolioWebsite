"""
evaluate_consistency.py

Multi-Year & Month-by-Month Strategy Consistency Matrix (2025 - 2026)

Evaluates:
  1. GAP_BOTTOM_LONG (Held to EOD Close)
  2. GAP_BOTTOM_LONG (1-Hour Hold: Exit 10:30 ET)
  3. GAP_BOTTOM_LONG (2-Hour Hold: Exit 11:30 ET)
  4. GAP_TOP_SHORT (Fade Gap Ups to Close)
  5. MOMENTUM_PRIOR_1M_TOP_LONG (Trend following: Buy 1-month winners)
  6. MOMENTUM_PRIOR_1D_TOP_LONG (Continuation: Buy yesterday's winners)
  7. MEAN_REV_5D_BOTTOM_LONG (Buy 5-day oversold pullbacks)

Breaks down returns:
  - Month-by-month across 2025 and 2026
  - Monthly win rate (% of months profitable)
  - Full-year 2025 vs Full-year 2026
  - Max monthly drawdown
"""

import os
import json
import logging
from datetime import datetime, date, timedelta
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)-8s  %(message)s")
log = logging.getLogger("consistency")

def run():
    log.info("Loading daily and intraday cache data...")

    # Load 2025 15-minute bars for intraday exit study
    table_15m = pq.read_table(
        "alpaca_bot/cache/518136e7f29c093570d4b6a5a0261eed.parquet",
        columns=["symbol", "date", "hour_et", "minute_et", "open", "close"]
    )
    df_15m = table_15m.to_pandas()
    df_15m["time_int"] = df_15m["hour_et"] * 100 + df_15m["minute_et"]
    df_15m = df_15m[(df_15m["time_int"] >= 930) & (df_15m["time_int"] <= 1545)]

    # Load daily bars across 2024-2026
    df1 = pq.read_table("alpaca_bot/cache/6503b346c06e5e2eeb48a147f56e9ad2.parquet",
                        columns=["symbol", "timestamp", "open", "close", "volume"]).to_pandas()
    df2 = pq.read_table("alpaca_bot/cache/093ed960b7e0934b028ef08713e10591.parquet",
                        columns=["symbol", "timestamp", "open", "close", "volume"]).to_pandas()
    daily = pd.concat([df1, df2]).drop_duplicates(subset=["symbol", "timestamp"])
    daily["date"] = pd.to_datetime(daily["timestamp"]).dt.date
    daily = daily.sort_values(["symbol", "date"]).reset_index(drop=True)

    # Filter out penny stocks < $3 and illiquid volume
    daily["prev_close"] = daily.groupby("symbol")["close"].shift(1)
    daily["dollar_vol"] = daily["close"] * daily["volume"]
    daily["gap"] = (daily["open"] / daily["prev_close"]) - 1.0
    daily["ret_intraday"] = (daily["close"] / daily["open"]) - 1.0

    # Multi-day momentum / mean-reversion lookbacks
    daily["ret_1d"] = (daily["close"] / daily["prev_close"]) - 1.0
    daily["ret_5d"] = (daily["close"] / daily.groupby("symbol")["close"].shift(5)) - 1.0
    daily["ret_1m"] = (daily["close"] / daily.groupby("symbol")["close"].shift(21)) - 1.0

    # Filter universe for liquid tradeable universe
    universe_path = "alpaca_bot/liquid_universe.json"
    if os.path.exists(universe_path):
        with open(universe_path) as f:
            u_set = set(json.load(f))
        daily = daily[daily["symbol"].isin(u_set)].copy()
        df_15m = df_15m[df_15m["symbol"].isin(u_set)].copy()

    # Filter for 2025 and 2026
    daily = daily[(daily["date"] >= date(2025, 1, 1)) & (daily["date"] <= date(2026, 6, 15))].copy()
    daily["month"] = pd.to_datetime(daily["date"]).dt.to_period("M")
    months = sorted(daily["month"].unique())
    log.info(f"Loaded {len(daily):,} bars across {len(months)} months ({months[0]} to {months[-1]}).")

    # Define strategy signal logic
    def pick_gap_bottom(df):
        c = df[(df["gap"] <= -0.04) & (df["gap"] >= -0.60)]
        return c.sort_values(["date", "gap"], ascending=[True, True]).groupby("date").head(25)

    def pick_gap_top(df):
        c = df[(df["gap"] >= 0.04) & (df["gap"] <= 0.60)]
        return c.sort_values(["date", "gap"], ascending=[True, False]).groupby("date").head(25)

    def pick_mom_1m(df):
        c = df[df["ret_1m"] > 0]
        return c.sort_values(["date", "ret_1m"], ascending=[True, False]).groupby("date").head(25)

    def pick_mom_1d(df):
        c = df[df["ret_1d"] > 0.02]
        return c.sort_values(["date", "ret_1d"], ascending=[True, False]).groupby("date").head(25)

    def pick_mean_rev_5d(df):
        c = df[df["ret_5d"] < -0.05]
        return c.sort_values(["date", "ret_5d"], ascending=[True, True]).groupby("date").head(25)

    strategies = {
        "GAP_BOTTOM_LONG (EOD Hold)": {
            "picker": pick_gap_bottom,
            "ret_fn": lambda p: p["ret_intraday"] - 0.0010
        },
        "GAP_TOP_SHORT (EOD Hold)": {
            "picker": pick_gap_top,
            "ret_fn": lambda p: -p["ret_intraday"] - 0.0010
        },
        "MOMENTUM_1M_TOP_LONG (Trend Following)": {
            "picker": pick_mom_1m,
            "ret_fn": lambda p: p["ret_intraday"] - 0.0010
        },
        "MOMENTUM_1D_TOP_LONG (Day Momentum)": {
            "picker": pick_mom_1d,
            "ret_fn": lambda p: p["ret_intraday"] - 0.0010
        },
        "MEAN_REV_5D_BOTTOM_LONG (Oversold Pullback)": {
            "picker": pick_mean_rev_5d,
            "ret_fn": lambda p: p["ret_intraday"] - 0.0010
        }
    }

    month_results = {}
    summary_stats = []

    for name, cfg in strategies.items():
        picks = cfg["picker"](daily).copy()
        picks["net_ret"] = cfg["ret_fn"](picks)

        # Daily mean returns
        day_rets = picks.groupby("date")["net_ret"].mean()
        
        # Monthly compounding returns
        m_returns = {}
        for m in months:
            m_dates = daily[daily["month"] == m]["date"].unique()
            m_day_rets = [day_rets.get(d, 0.0) for d in m_dates]
            m_ret = (np.prod([1.0 + r for r in m_day_rets]) - 1.0) * 100.0
            m_returns[str(m)] = round(m_ret, 2)

        month_results[name] = m_returns

        # Summary statistics
        vals = list(m_returns.values())
        y2025 = [v for k, v in m_returns.items() if k.startswith("2025")]
        y2026 = [v for k, v in m_returns.items() if k.startswith("2026")]

        ret_2025 = (np.prod([1.0 + v/100.0 for v in y2025]) - 1.0) * 100.0 if y2025 else 0.0
        ret_2026 = (np.prod([1.0 + v/100.0 for v in y2026]) - 1.0) * 100.0 if y2026 else 0.0

        n_pos_months = sum(1 for v in vals if v > 0)
        pct_pos_months = (n_pos_months / len(vals)) * 100.0 if vals else 0.0
        avg_month = np.mean(vals)
        worst_month = min(vals)
        best_month = max(vals)

        summary_stats.append({
            "Strategy": name,
            "2025 Return (%)": round(ret_2025, 1),
            "2026 Return (%)": round(ret_2026, 1),
            "Profitable Months": f"{n_pos_months}/{len(vals)} ({pct_pos_months:.0f}%)",
            "Avg Month (%)": round(avg_month, 2),
            "Best Month (%)": round(best_month, 1),
            "Worst Month (%)": round(worst_month, 1),
        })

    sum_df = pd.DataFrame(summary_stats)
    m_df = pd.DataFrame(month_results)

    # Save detailed matrix
    sum_df.to_csv("results/strategy_consistency_summary.csv", index=False)
    m_df.to_csv("results/strategy_monthly_matrix.csv")

    print("\n" + "="*95)
    print("STRATEGY CONSISTENCY & RELIABILITY MATRIX (2025 - 2026)")
    print("="*95)
    print(sum_df.to_string(index=False))
    print("="*95)

    print("\nMONTH-BY-MONTH RETURN MATRIX (%):")
    print(m_df.to_string())
    print("="*95)

    return sum_df, m_df

if __name__ == "__main__":
    run()

