"""
live_trader.py

Runs the top strategies live on Alpaca paper trading.

STRATEGIES & THEIR EXECUTION TIMING:
  1. GAP_BOTTOM_LONG                         -> LONG   at market open (09:30 ET)
  2. INTRADAY_15M_SIGNAL_TOP_SHORT           -> SHORT  at 09:45 ET

OPTIMIZED ARCHITECTURE:
  - Wakes up 15 minutes prior to open (09:15 ET) to pre-fetch universe & metrics
  - Pre-cached data ensures 0-second latency at 09:30:00 market open
  - Uses explicit DataFeed.IEX for free-tier compatibility
  - Targets top liquid US equities for <5s data fetches
  - 100% intraday liquidation at 15:55 ET into clean cash
  - Auto-updates SQLite database and GitHub Pages live dashboard
"""

import argparse
import json
import logging
import math
import os
import sys
import time
from datetime import datetime, timedelta, date
from zoneinfo import ZoneInfo

import pandas as pd
from dotenv import load_dotenv

from alpaca.trading.client import TradingClient
from alpaca.trading.requests import MarketOrderRequest, GetAssetsRequest
from alpaca.trading.enums import OrderSide, TimeInForce, AssetClass, AssetStatus
from alpaca.data.historical.stock import StockHistoricalDataClient
from alpaca.data.requests import StockBarsRequest, StockLatestBarRequest
from alpaca.data.timeframe import TimeFrame, TimeFrameUnit
from alpaca.data.enums import DataFeed

from data_layer import get_daily_bars, get_15min_bars
from metrics import add_metrics
from strategy import (
    rank_latest_prior_returns,
    rank_by_gap,
    rank_by_intraday_move,
)
import tracker
from eod_report import run_recap
import status_publisher

tracker.init_db()

load_dotenv()

# ── Logging ────────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("live_trader.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("live_trader")

ET = ZoneInfo("America/New_York")

# ══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════

API_KEY    = os.getenv("APCA_API_KEY_ID") or os.getenv("ALPACA_API_KEY")
API_SECRET = os.getenv("APCA_API_SECRET_KEY") or os.getenv("ALPACA_SECRET_KEY")

if not API_KEY or not API_SECRET:
    raise ValueError("Missing APCA_API_KEY_ID or APCA_API_SECRET_KEY in .env")

BOT_VERSION = "3.0.0"

# ── Enabled strategies for live trading ────────────────────────────────────────
ENABLED_STRATEGIES = [
    "GAP_BOTTOM_LONG",  # Long oversold gap-downs at 09:30 ET -> Exit at 10:30 ET (1-hour hold)
    "GAP_TOP_SHORT",    # Short overextended gap-ups at 09:30 ET -> Exit at 15:50 ET (EOD close)
]

N_STRATEGIES = max(1, len(ENABLED_STRATEGIES))

# Allocation per stock pick (2.5% per stock: 20 Long + 20 Short = 100% gross exposure, 0% market beta)
POSITION_PCT   = 0.025
TOP_N          = 20
STOP_LOSS_PCT  = 0.06  # 6.0% maximum adverse move cut per position

# Universe filters
MIN_PRICE        = 10.0   # Real liquid institutional equities only (>= $10, no penny stock splits)
MIN_DOLLAR_VOL   = 1_000_000.0
UNIVERSE_LIMIT   = 1500  # 1,500 liquid ETB equities for wider opportunity coverage

DAILY_LOOKBACK_DAYS = 45 # 45 days is fast and plenty for 1m returns and gaps
INTRADAY_LOOKBACK_DAYS = 5 # lookback for intraday bars
LIQUIDATE_MINUTES_BEFORE_CLOSE = 10  # -> 15:50 ET (10-min safety buffer against MOC volatility & trading halts)
MAX_OPEN_LAG_MINUTES = 15
ORDER_FILL_TIMEOUT_SECS = 30

trade_client = TradingClient(API_KEY, API_SECRET, paper=True)
data_client  = StockHistoricalDataClient(API_KEY, API_SECRET)


# ── Market clock helpers ───────────────────────────────────────────────────────

def get_clock():
    return trade_client.get_clock()


def is_market_open() -> bool:
    return get_clock().is_open


def today_et() -> date:
    return datetime.now(tz=ET).date()


def now_et() -> datetime:
    return datetime.now(tz=ET)


def wait_until_et(target_hour: int, target_minute: int, label: str = ""):
    """Sleep until a specific time today in US/Eastern."""
    target = now_et().replace(
        hour=target_hour, minute=target_minute, second=0, microsecond=0
    )
    delta = (target - now_et()).total_seconds()
    if delta > 0:
        log.info(f"Waiting {delta/60:.1f} min until {target_hour:02d}:{target_minute:02d} ET"
                 + (f" [{label}]" if label else ""))
        time.sleep(delta)


def market_opened_minutes_ago() -> float:
    """Minutes since 9:30 ET today."""
    open_time = now_et().replace(hour=9, minute=30, second=0, microsecond=0)
    return (now_et() - open_time).total_seconds() / 60.0


# ── Account helpers ────────────────────────────────────────────────────────────

def get_equity() -> float:
    acct = trade_client.get_account()
    return float(acct.equity)


def get_strategy_capital() -> float:
    """Each strategy gets equity / N_STRATEGIES."""
    return get_equity() / N_STRATEGIES


def get_open_positions() -> dict:
    """Returns {symbol: position_obj}."""
    positions = trade_client.get_all_positions()
    return {p.symbol: p for p in positions}


# ── Order helpers ──────────────────────────────────────────────────────────────

def submit_market_order(symbol: str, qty: float, side: OrderSide,
                        strategy_label: str,
                        ref_price: float = None,
                        direction: str = None,
                        session: str = None) -> bool:
    """
    Submit a market order and persist to SQLite tracker.

    SHORT orders: Alpaca strictly requires whole integer shares.
    LONG orders: fractional shares supported up to 4 decimal places.
    """
    try:
        is_short_dir = direction == "SHORT"

        if is_short_dir and side == OrderSide.SELL:
            # Opening SHORT: whole shares only, round down to stay within budget
            qty_to_submit = int(math.floor(qty))
            if qty_to_submit < 1:
                log.debug(f"  [{strategy_label}] skip {symbol}: calculated < 1 whole share")
                return False
        elif is_short_dir and side == OrderSide.BUY:
            # Closing SHORT (buy to cover): must be whole integer shares
            qty_to_submit = int(round(qty))
            if qty_to_submit < 1:
                return False
        else:
            # LONG orders (open BUY or close SELL): fractional supported
            qty_to_submit = round(qty, 4)
            if qty_to_submit <= 0:
                return False

        req = MarketOrderRequest(
            symbol=symbol,
            qty=qty_to_submit,
            side=side,
            time_in_force=TimeInForce.DAY,
        )
        order = trade_client.submit_order(req)
        order_id_str = str(order.id)
        log.info(f"  [{strategy_label}] {side.value.upper()} {qty_to_submit} {symbol} "
                 f"-> order {order_id_str[:8]}...")

        # Determine leg type for tracking
        is_close_leg = (side == OrderSide.SELL and direction == "LONG") or \
                       (side == OrderSide.BUY  and direction == "SHORT")

        price = ref_price or 0.0

        if not is_close_leg:
            tracker.record_open(
                strategy=strategy_label,
                symbol=symbol,
                direction=direction or ("LONG" if side == OrderSide.BUY else "SHORT"),
                shares=qty_to_submit,
                price=price,
                trade_date=today_et(),
                session=session,
            )
        else:
            tracker.record_close(
                strategy=strategy_label,
                symbol=symbol,
                direction=direction,
                shares=qty_to_submit,
                price=price,
                trade_date=today_et(),
            )
        return True

    except Exception as e:
        log.error(f"  [{strategy_label}] Order failed for {symbol}: {e}")
        return False


def liquidate_all(label: str = "EOD"):
    """
    Close all open positions by looking up their direction in SQLite tracker.
    Long positions -> sell. Short positions -> buy to cover.
    """
    open_trades = tracker.get_open_positions()
    trade_map = {t["symbol"]: t for t in open_trades}

    positions = get_open_positions()
    if not positions:
        log.info(f"[{label}] No open positions to liquidate.")
        return

    log.info(f"[{label}] Liquidating {len(positions)} positions...")
    for sym, pos in positions.items():
        qty = abs(float(pos.qty))
        cur_price = float(pos.current_price) if getattr(pos, "current_price", None) else None
        t_meta = trade_map.get(sym)
        strategy = t_meta["strategy"] if t_meta else label

        if float(pos.qty) < 0:
            # Short position -> buy to cover
            submit_market_order(
                sym, qty, OrderSide.BUY, strategy,
                ref_price=cur_price, direction="SHORT", session="CLOSE"
            )
        else:
            # Long position -> sell
            submit_market_order(
                sym, qty, OrderSide.SELL, strategy,
                ref_price=cur_price, direction="LONG", session="CLOSE"
            )

    # Wait for fills
    for _ in range(ORDER_FILL_TIMEOUT_SECS):
        time.sleep(1)
        remaining = get_open_positions()
        if not remaining:
            log.info(f"[{label}] All positions liquidated successfully.")
            return
    log.warning(f"[{label}] Liquidation timeout: {len(get_open_positions())} positions remaining")


def log_event(event_type: str, data: dict):
    """Record an intraday operational or risk management event for live audit and website tracking."""
    event = {
        "timestamp": now_et().isoformat(),
        "time_str": now_et().strftime("%I:%M:%S %p ET"),
        "event_type": event_type,
        **data
    }
    log.info(f"[{event_type}] {data}")
    try:
        events_file = Path(__file__).parent / "intraday_events.jsonl"
        with open(events_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(event) + "\n")
    except Exception as e:
        log.debug(f"Failed to record intraday event: {e}")


def liquidate_strategy(strategy_label: str, label: str = ""):
    """
    Liquidate only positions belonging to a specific strategy.
    Long positions -> sell. Short positions -> buy to cover.
    """
    open_trades = tracker.get_open_positions()
    strat_trades = [t for t in open_trades if t["strategy"] == strategy_label]
    if not strat_trades:
        log.info(f"[{strategy_label}] No open positions to liquidate for {label}.")
        return

    positions = get_open_positions()
    log.info(f"[{strategy_label}] Liquidating {len(strat_trades)} positions for {label}...")
    for t in strat_trades:
        sym = t["symbol"]
        pos = positions.get(sym)
        if not pos:
            continue
        qty = abs(float(pos.qty))
        cur_price = float(pos.current_price) if getattr(pos, "current_price", None) else None
        direction = t["direction"]
        side = OrderSide.SELL if direction == "LONG" else OrderSide.BUY

        submit_market_order(
            sym, qty, side, strategy_label,
            ref_price=cur_price, direction=direction, session=label or "EXIT"
        )

    log_event("STRATEGY_EXIT", {
        "strategy": strategy_label,
        "label": label,
        "positions_closed": len(strat_trades),
        "symbols": [t["symbol"] for t in strat_trades]
    })

    # Wait for fills
    strat_symbols = {t["symbol"] for t in strat_trades}
    for _ in range(ORDER_FILL_TIMEOUT_SECS):
        time.sleep(1)
        remaining = [sym for sym in get_open_positions().keys() if sym in strat_symbols]
        if not remaining:
            log.info(f"[{strategy_label}] All {label} positions liquidated successfully.")
            return
    log.warning(f"[{strategy_label}] {len(remaining)} positions still pending liquidation after timeout.")


def check_stop_losses(max_loss_pct: float = STOP_LOSS_PCT):
    """
    Active risk management monitor: cuts any position if unrealized loss exceeds max_loss_pct (e.g. -6%).
    Protects against runaway adverse moves or unexpected corporate actions.
    """
    positions = get_open_positions()
    if not positions:
        return
    open_trades = {t["symbol"]: t for t in tracker.get_open_positions()}

    for sym, pos in positions.items():
        try:
            unreal_plpc = float(pos.unrealized_plpc) if getattr(pos, "unrealized_plpc", None) is not None else 0.0
            if unreal_plpc <= -max_loss_pct:
                qty = abs(float(pos.qty))
                cur_price = float(pos.current_price) if getattr(pos, "current_price", None) else None
                t_meta = open_trades.get(sym)
                strat = t_meta["strategy"] if t_meta else "STOP_LOSS"
                direction = "SHORT" if float(pos.qty) < 0 else "LONG"
                side = OrderSide.BUY if direction == "SHORT" else OrderSide.SELL
                log.warning(f"  [STOP_LOSS] {sym} ({direction}) loss is {unreal_plpc*100:.2f}% (exceeds -{max_loss_pct*100:.1f}%)! Cutting position immediately...")

                log_event("STOP_LOSS_TRIGGER", {
                    "symbol": sym,
                    "strategy": strat,
                    "direction": direction,
                    "unrealized_loss_pct": round(unreal_plpc * 100, 2),
                    "exit_price": cur_price,
                    "qty": qty,
                    "reason": f"Cut at market: loss of {unreal_plpc*100:.2f}% exceeded stop threshold of -{max_loss_pct*100:.1f}%"
                })

                submit_market_order(
                    sym, qty, side, strat,
                    ref_price=cur_price, direction=direction, session="STOP_LOSS"
                )
        except Exception as e:
            log.error(f"Error checking stop loss for {sym}: {e}")


# ── Data helpers ───────────────────────────────────────────────────────────────

def fetch_universe_symbols():
    """Load tradable liquid US equities and track easy-to-borrow shortable assets."""
    curated_path = os.path.join(os.path.dirname(__file__), "liquid_universe.json")
    curated_symbols = None
    if os.path.exists(curated_path):
        try:
            with open(curated_path, "r", encoding="utf-8") as f:
                curated_symbols = json.load(f)
            log.info(f"Loaded {len(curated_symbols)} curated liquid symbols from {os.path.basename(curated_path)}")
        except Exception as e:
            log.warning(f"Could not load curated symbols from {curated_path}: {e}")

    assets = trade_client.get_all_assets(
        GetAssetsRequest(asset_class=AssetClass.US_EQUITY, status=AssetStatus.ACTIVE)
    )
    asset_map = {a.symbol: a for a in assets}

    symbols = []
    shortable_set = set()

    if curated_symbols:
        for sym in curated_symbols:
            a = asset_map.get(sym)
            if not a:
                continue
            if not getattr(a, "tradable", False):
                continue
            symbols.append(sym)
            if getattr(a, "shortable", False) and getattr(a, "easy_to_borrow", False):
                shortable_set.add(sym)
    else:
        for a in assets:
            if not getattr(a, "tradable", False):
                continue
            if not getattr(a, "fractionable", False):
                continue
            if a.exchange not in ("NASDAQ", "NYSE"):
                continue
            if "ETF" in (getattr(a, "name", "") or "") or "/" in a.symbol or "." in a.symbol:
                continue

            symbols.append(a.symbol)
            if getattr(a, "shortable", False) and getattr(a, "easy_to_borrow", False):
                shortable_set.add(a.symbol)

    # Focus on top liquid universe to keep data fetches <5 seconds
    if len(symbols) > UNIVERSE_LIMIT:
        symbols = symbols[:UNIVERSE_LIMIT]

    log.info(f"Universe: {len(symbols):,} liquid symbols ({len(shortable_set):,} shortable/ETB)")
    return symbols, shortable_set


def fetch_daily_metrics(symbols: list[str]) -> pd.DataFrame:
    """Pull DAILY_LOOKBACK_DAYS of daily bars and compute metrics."""
    from datetime import timezone
    end_dt   = datetime.combine(today_et() + timedelta(days=1),
                                 datetime.min.time()).replace(tzinfo=timezone.utc)
    start_dt = datetime.combine(today_et() - timedelta(days=DAILY_LOOKBACK_DAYS),
                                 datetime.min.time()).replace(tzinfo=timezone.utc)

    log.info(f"Fetching daily bars {start_dt.date()} → {end_dt.date()}...")
    daily = get_daily_bars(symbols, start_dt, end_dt, use_cache=True)
    if daily.empty:
        raise RuntimeError("No daily bars returned — check API credentials and universe.")
    log.info(f"  {len(daily):,} rows. Computing metrics...")
    metrics = add_metrics(daily)
    metrics["date"] = pd.to_datetime(metrics["date"]).dt.date
    return metrics


def fetch_15m_bars_today(symbols: list[str]) -> pd.DataFrame:
    """Pull last INTRADAY_LOOKBACK_DAYS of 15-min bars for liquid symbols."""
    from datetime import timezone
    end_dt   = datetime.combine(today_et() + timedelta(days=1),
                                 datetime.min.time()).replace(tzinfo=timezone.utc)
    start_dt = datetime.combine(today_et() - timedelta(days=INTRADAY_LOOKBACK_DAYS),
                                 datetime.min.time()).replace(tzinfo=timezone.utc)

    fetch_symbols = symbols[:250] if len(symbols) > 250 else symbols
    log.info(f"Fetching 15-min bars for {len(fetch_symbols)} symbols {start_dt.date()} → {end_dt.date()}...")
    bars = get_15min_bars(fetch_symbols, start_dt, end_dt,
                          chunk_size=100, use_cache=False)
    log.info(f"  {len(bars):,} intraday rows")
    return bars


# ── Strategy signal generators ─────────────────────────────────────────────────

def get_open_signals(metrics: pd.DataFrame, shortable_set: set, today: date) -> dict:
    """
    Strategies that trade at market open (09:30 ET).
    Computes both GAP_BOTTOM_LONG and GAP_TOP_SHORT from real-time open prices vs prior close.
    """
    signals = {}
    try:
        latest_date = metrics["date"].max()
        liquid_cands = (metrics[metrics["date"] == latest_date]
                        .sort_values("dollar_volume", ascending=False)["symbol"].tolist())
        if liquid_cands:
            prev_closes = metrics[metrics["date"] == latest_date].set_index("symbol")["close"].to_dict()
            latest_bars = {}
            chunk_size = 250
            for i in range(0, len(liquid_cands), chunk_size):
                ch = liquid_cands[i:i+chunk_size]
                bars_req = StockLatestBarRequest(symbol_or_symbols=ch, feed=DataFeed.IEX)
                latest_bars.update(data_client.get_stock_latest_bar(bars_req))

            gap_down_rows = []
            gap_up_rows = []

            for sym, b in latest_bars.items():
                p_close = prev_closes.get(sym)
                entry_px = b.open if (b.open and b.open > 0) else b.close
                if p_close and p_close >= MIN_PRICE and entry_px and entry_px >= MIN_PRICE:
                    gap = (entry_px / p_close) - 1.0

                    # Gap Down: -60% <= gap <= -4% (oversold panic for 1h morning bounce)
                    if -0.60 <= gap <= -0.04:
                        gap_down_rows.append({
                            "date": today, "symbol": sym,
                            "entry_price": entry_px, "rank_score": gap
                        })

                    # Gap Up: +4% <= gap <= +60% (overextended hype for day fade)
                    if 0.04 <= gap <= 0.60 and sym in shortable_set:
                        gap_up_rows.append({
                            "date": today, "symbol": sym,
                            "entry_price": entry_px, "rank_score": gap
                        })

            if "GAP_BOTTOM_LONG" in ENABLED_STRATEGIES and gap_down_rows:
                gap_df = pd.DataFrame(gap_down_rows).sort_values("rank_score", ascending=True).head(TOP_N)
                gap_df["rank"] = range(1, len(gap_df) + 1)
                signals["GAP_BOTTOM_LONG"] = (gap_df, "LONG")
                log.info(f"  [GAP_BOTTOM_LONG] Found {len(gap_df)} gap-down candidates (worst: "
                         f"{gap_df.iloc[0]['symbol']} {gap_df.iloc[0]['rank_score']*100:.1f}%)")

            if "GAP_TOP_SHORT" in ENABLED_STRATEGIES and gap_up_rows:
                gap_df = pd.DataFrame(gap_up_rows).sort_values("rank_score", ascending=False).head(TOP_N)
                gap_df["rank"] = range(1, len(gap_df) + 1)
                signals["GAP_TOP_SHORT"] = (gap_df, "SHORT")
                log.info(f"  [GAP_TOP_SHORT] Found {len(gap_df)} gap-up short candidates (top: "
                         f"{gap_df.iloc[0]['symbol']} +{gap_df.iloc[0]['rank_score']*100:.1f}%)")

    except Exception as e:
        log.warning(f"Failed to fetch real-time gaps at open: {e}")

    return signals


def get_15m_signals(metrics: pd.DataFrame, bars_15m: pd.DataFrame,
                    shortable_set: set, today: date) -> dict:
    """
    Strategies that trade at 09:45 ET (after first 15-min bar closes).
    """
    signals = {}

    # 2. INTRADAY_15M_SIGNAL_TOP_SHORT
    if "INTRADAY_15M_SIGNAL_TOP_SHORT" in ENABLED_STRATEGIES and not bars_15m.empty:
        try:
            r = rank_by_intraday_move(
                bars_15m=bars_15m, entry_bar="15M", top_n=TOP_N,
                min_price=MIN_PRICE, ascending=False,
            )
            r = r[r["date"] == today]
            r = r[r["rank_score"] > 0]
            r = r[r["symbol"].isin(shortable_set)]

            # Prevent collision: Exclude any symbols we are currently holding LONG from market open!
            try:
                current_longs = {p.symbol for p in trade_client.get_all_positions() if float(p.qty) > 0}
                if current_longs:
                    r = r[~r["symbol"].isin(current_longs)]
            except Exception as e:
                log.warning(f"Could not verify open long positions: {e}")

            if not r.empty:
                signals["INTRADAY_15M_SIGNAL_TOP_SHORT"] = (r, "SHORT")
                log.info(f"  [INTRADAY_15M_SIGNAL_TOP_SHORT] Found {len(r)} short candidates")
        except Exception as e:
            log.warning(f"Failed to generate 15M signals: {e}")

    return signals


# ── Execution dispatcher ───────────────────────────────────────────────────────

def execute_signals(signals: dict, strategy_capital: float, label: str = ""):
    """
    Take a dict of {strategy_label: (signals_df, direction)} and place orders.
    Each stock gets POSITION_PCT of strategy_capital.
    """
    if not signals:
        log.info(f"[{label}] No signals to execute.")
        return

    total_equity = get_equity()
    per_stock_budget = total_equity * POSITION_PCT
    log.info(f"[{label}] Executing signals. Budget/stock: ${per_stock_budget:,.2f} ({POSITION_PCT*100:.1f}% of total equity)")

    for strat_label, (df, direction) in signals.items():
        side = OrderSide.BUY if direction == "LONG" else OrderSide.SELL
        log.info(f"  Strategy: {strat_label} ({len(df)} picks, {direction})")

        for _, row in df.iterrows():
            sym   = row["symbol"]
            price = row.get("entry_price")

            if not price or price <= 0:
                continue

            shares = per_stock_budget / price
            submit_market_order(
                symbol=sym,
                qty=shares,
                side=side,
                strategy_label=strat_label,
                ref_price=price,
                direction=direction,
                session=label,
            )


# ── Status display ─────────────────────────────────────────────────────────────

def print_status():
    """Print current portfolio state and open positions."""
    equity    = get_equity()
    acct      = trade_client.get_account()
    cash      = float(acct.cash)
    positions = get_open_positions()

    print(f"\n{'='*60}")
    print(f"  PAPER ACCOUNT STATUS  {now_et().strftime('%Y-%m-%d %H:%M:%S ET')}")
    print(f"{'='*60}")
    print(f"  Equity : ${equity:>12,.2f}")
    print(f"  Cash   : ${cash:>12,.2f}")
    print(f"  Positions: {len(positions)}")
    print()

    if positions:
        rows = []
        for sym, p in sorted(positions.items()):
            qty      = float(p.qty)
            mkt_val  = float(p.market_value)
            unreal   = float(p.unrealized_pl)
            unreal_p = float(p.unrealized_plpc) * 100
            side_str = "SHORT" if qty < 0 else "LONG"
            rows.append({
                "symbol": sym, "side": side_str, "qty": f"{qty:.3f}",
                "mkt_val": f"${mkt_val:,.2f}",
                "unreal_pl": f"${unreal:+,.2f}", "unreal_pct": f"{unreal_p:+.2f}%"
            })
        df = pd.DataFrame(rows)
        print(df.to_string(index=False))
    print()


# ── Main daily loop ────────────────────────────────────────────────────────────

def run_day():
    """Execute one full trading day: pre-fetch → open → 15M → liquidate at close."""
    today = today_et()
    log.info(f"\n{'='*60}")
    log.info(f"  TRADING DAY: {today}")
    log.info(f"{'='*60}")

    # ── 1. Pre-fetch data (starts before open at 09:15 ET) ──────────────────────
    log.info("Pre-fetching liquid universe and daily metrics...")

    # Pre-open cleanup: ONLY close leftover positions if strictly before market open (prior to 09:25 ET).
    # If the bot is started or recovers mid-day, existing positions are today's active trades and must NOT be liquidated!
    from datetime import time as dt_time
    if now_et().time() < dt_time(9, 25):
        lingering = get_open_positions()
        if lingering:
            log.warning(f"Found {len(lingering)} lingering open positions before session! Liquidating...")
            liquidate_all(label="PRE_OPEN_CLEANUP")

    symbols, shortable_set = fetch_universe_symbols()
    metrics = fetch_daily_metrics(symbols)
    start_equity = get_equity()
    log.info(f"Pre-fetch complete. Starting equity: ${start_equity:,.2f}")

    # Push status update so dashboard shows active preparation
    try:
        status_publisher.update_and_publish()
    except Exception as e:
        log.debug(f"Status publisher update: {e}")

    # ── 2. OPEN WINDOW (09:30 ET) ──────────────────────────────────────────────
    wait_until_et(9, 30, "MARKET OPEN")

    lag = market_opened_minutes_ago()
    if lag > MAX_OPEN_LAG_MINUTES:
        log.warning(f"Market opened {lag:.1f} min ago (> {MAX_OPEN_LAG_MINUTES}m) — skipping open orders")
    else:
        if not is_market_open():
            log.warning("Market not open at 9:30 — skipping open window")
        else:
            strategy_capital = get_strategy_capital()
            open_signals = get_open_signals(metrics, shortable_set, today)
            execute_signals(open_signals, strategy_capital, label="OPEN")
            try:
                status_publisher.update_and_publish()
            except Exception as e:
                log.debug(f"Status publisher update: {e}")

    # ── 3. 09:30 - 10:30 ET: Active Holding & 1-Hour Long Exit ──────────────────
    target_1h = now_et().replace(hour=10, minute=30, second=0, microsecond=0)
    log.info("Positions entered. Monitoring active stop-losses until 10:30 ET (1-hour bounce exit)...")

    last_status_pub = time.time()
    while now_et() < target_1h:
        check_stop_losses(STOP_LOSS_PCT)
        time.sleep(30)
        # Heartbeat update every 5 minutes
        if time.time() - last_status_pub > 300:
            try:
                status_publisher.update_and_publish()
                last_status_pub = time.time()
            except Exception as e:
                log.debug(f"Heartbeat publish error: {e}")

    # Liquidate Longs at 10:30 ET to harvest peak morning bounce
    log.info("10:30 ET reached: Liquidating GAP_BOTTOM_LONG to lock in 1-hour morning bounce...")
    liquidate_strategy("GAP_BOTTOM_LONG", label="1H_EXIT")
    try:
        status_publisher.update_and_publish()
    except Exception as e:
        log.debug(f"Status publisher update: {e}")

    # ── 4. 10:30 - 15:50 ET: Short Holding Window ──────────────────────────────
    close_hour   = 15
    close_minute = 60 - LIQUIDATE_MINUTES_BEFORE_CLOSE  # = 50 (15:50 ET)
    target_liq   = now_et().replace(hour=close_hour, minute=close_minute, second=0, microsecond=0)
    log.info(f"Longs closed. Holding short positions until 15:{close_minute:02d} ET with active stop loss...")

    last_status_pub = time.time()
    while now_et() < target_liq:
        check_stop_losses(STOP_LOSS_PCT)
        time.sleep(30)
        # Heartbeat update every 15 minutes
        if time.time() - last_status_pub > 900:
            try:
                status_publisher.update_and_publish()
                last_status_pub = time.time()
            except Exception as e:
                log.debug(f"Heartbeat publish error: {e}")

    # ── 5. EOD LIQUIDATION (15:50 ET) ──────────────────────────────────────────
    liquidate_all(label="EOD")
    end_equity = get_equity()
    log.info(f"Day complete. Final equity: ${end_equity:,.2f}")

    # ── 6. EOD SNAPSHOT & RECAP ────────────────────────────────────────────────
    try:
        tracker.snapshot_eod(today, equity_start=start_equity, equity_end=end_equity)
        run_recap(today)
        # Daily reconciliation against theoretical bars
        try:
            import eod_reconciliation
            eod_reconciliation.reconcile(today)
        except Exception as e:
            log.debug(f"EOD reconciliation: {e}")
        status_publisher.update_and_publish()
    except Exception as e:
        log.warning(f"EOD snapshot/recap error: {e}")

    # Prevent loop re-entry: sleep until market close (16:00 ET)
    wait_until_et(16, 0, "OFFICIAL MARKET CLOSE")


def main():
    parser = argparse.ArgumentParser(description="Live trader — Alpaca paper")
    parser.add_argument("--version",   action="version", version=f"%(prog)s {BOT_VERSION}")
    parser.add_argument("--once",      action="store_true",
                        help="Run one trading day then exit")
    parser.add_argument("--status",    action="store_true",
                        help="Print current positions and exit")
    parser.add_argument("--liquidate", action="store_true",
                        help="Close all positions and exit")
    args = parser.parse_args()

    if args.status:
        print_status()
        return

    if args.liquidate:
        log.info("Manual liquidation requested.")
        liquidate_all("MANUAL")
        return

    if args.once:
        clock = get_clock()
        if not clock.is_open:
            log.warning(f"Market is not open right now (next open: {clock.next_open}). "
                        f"Running anyway with --once...")
        run_day()
        return

    # ── Continuous mode: schedule every trading day ───────────────────────────
    log.info(f"Starting continuous live trader (v{BOT_VERSION}). Ctrl+C to stop.")
    last_traded_date = None

    while True:
        try:
            clock = get_clock()
            now = now_et()
            today = today_et()

            # If market is currently open: execute today's session if not already done
            if clock.is_open:
                if last_traded_date == today:
                    log.info(f"Today's session ({today}) already executed. Waiting for market close...")
                    wait_until_et(16, 0, "MARKET CLOSE")
                    time.sleep(30)
                    continue

                run_day()
                last_traded_date = today
                continue

            next_open = clock.next_open.astimezone(ET)

            # Wake up 60 minutes before market open (08:30 ET) for full pre-fetch & caching
            prep_time = next_open - timedelta(minutes=60)
            seconds_to_prep = (prep_time - now).total_seconds()

            if seconds_to_prep > 0:
                hours = seconds_to_prep / 3600.0
                log.info(f"Market closed. Next open: {next_open.strftime('%Y-%m-%d %H:%M ET')}. "
                         f"Sleeping {hours:.1f}h until pre-fetch at {prep_time.strftime('%H:%M ET')}...")
                time.sleep(seconds_to_prep)
            else:
                # Within 60 minutes of open: run pre-fetch and wait for 09:30 open!
                run_day()
                last_traded_date = today

        except KeyboardInterrupt:
            log.info("Interrupted. Liquidating before exit...")
            liquidate_all("INTERRUPT")
            break
        except Exception as e:
            log.exception(f"ERROR in continuous live trader: {e}")
            log.info("Sleeping 60s before retry...")
            time.sleep(60)


if __name__ == "__main__":
    main()