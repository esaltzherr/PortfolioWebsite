import numpy as np
import pandas as pd


LOOKBACKS = {
    "ret_1d": 1,
    "ret_5d": 5,
    "ret_10d": 10,
    "ret_1m": 21,
    "ret_6m": 126,
    "ret_1y": 252,
}


def add_metrics(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df

    out = df.copy()
    out = out.sort_values(["symbol", "timestamp"]).reset_index(drop=True)

    out["prev_close"] = out.groupby("symbol")["close"].shift(1)

    out["move_vs_prev_close"] = np.where(
        out["prev_close"] > 0,
        (out["close"] / out["prev_close"]) - 1.0,
        np.nan,
    )

    out["move_vs_open"] = np.where(
        out["open"] > 0,
        (out["close"] / out["open"]) - 1.0,
        np.nan,
    )

    for col_name, lookback in LOOKBACKS.items():
        prior_col = f"close_{lookback}d_ago"
        out[prior_col] = out.groupby("symbol")["close"].shift(lookback)
        out[col_name] = np.where(
            out[prior_col] > 0,
            (out["close"] / out[prior_col]) - 1.0,
            np.nan,
        )

    # keep this alias so your existing 52W logic still works
    out["change_52w"] = out["ret_1y"]
    out["dollar_volume"] = out["close"] * out["volume"]

    return out


def get_latest_available_date(df: pd.DataFrame, selected_date):
    if df.empty:
        return None

    selected_date = pd.to_datetime(selected_date).date()
    available_dates = sorted(pd.to_datetime(df["date"]).dt.date.unique())
    valid_dates = [d for d in available_dates if d <= selected_date]

    if not valid_dates:
        return None

    return valid_dates[-1]


def snapshot_for_date(df: pd.DataFrame, selected_date):
    actual_date = get_latest_available_date(df, selected_date)

    if actual_date is None:
        return pd.DataFrame(), None

    snap = df[df["date"] == actual_date].copy()
    snap = snap.sort_values("change_52w", ascending=False).reset_index(drop=True)

    return snap, actual_date