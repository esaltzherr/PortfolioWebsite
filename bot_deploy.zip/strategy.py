"""
strategy.py

Ranking functions — all return the same schema:
    date, symbol, entry_price, rank_score, rank

entry_price = the price the backtest uses to BUY the position.

Functions:
  rank_by_prior_returns()   multi-day rolling returns from daily bars
                             entry_price_col="close"  -> OVERNIGHT (buy at close)
                             entry_price_col="open"   -> INTRADAY_OPEN (buy at next open, no lookahead)

  rank_by_gap()             overnight gap signal: (today open / yesterday close) - 1
                             No lookahead — gap is known at market open.
                             entry_price = today's open (you act on the gap at the open)

  rank_by_intraday_move()   15-min bar based ranking, covers 15M, 30M, and 1H entries
                             rank_score = (bar_N_close / day_open) - 1
                             entry_price = the close of the target bar
"""

import pandas as pd

VALID_METRICS = {"ret_1d", "ret_5d", "ret_10d", "ret_1m", "ret_6m", "ret_1y"}


# ── Helpers ────────────────────────────────────────────────────────────────────

def _normalise_date(d):
    """Ensure d is a datetime.date regardless of source type."""
    if hasattr(d, "date"):
        return d.date()
    return d


def _apply_filters(rankings, side, loser_min=5.0, loser_max=60.0):
    """Apply TOP (winners only) or BOTTOM (loser band) filter."""
    if rankings.empty:
        return rankings.copy()
    if side == "TOP":
        return rankings[rankings["rank_score"] > 0].copy()
    else:
        lo = -abs(loser_min / 100.0)
        hi = -abs(loser_max / 100.0)
        lower_bound = min(lo, hi)
        upper_bound = max(lo, hi)
        return rankings[
            (rankings["rank_score"] >= lower_bound) & (rankings["rank_score"] <= upper_bound)
        ].copy()


# ── 1. Prior multi-day return ranking ─────────────────────────────────────────

def rank_by_prior_returns(
    metrics_df: pd.DataFrame,
    rank_by: str = "ret_5d",
    top_n: int = 100,
    min_price: float = 3.0,
    min_dollar_volume: float = 0.0,
    ascending: bool = False,
    entry_price_col: str = "close",
) -> pd.DataFrame:
    """
    Rank by a prior rolling return metric.

    No lookahead guarantee:
      entry_price_col="close" -> rank on day T, entry at day T close (MOC order)
      entry_price_col="open"  -> rank on day T-1, entry at day T open (next morning)
    """
    if rank_by not in VALID_METRICS:
        raise ValueError(f"rank_by must be one of {VALID_METRICS}")

    df = metrics_df.copy()
    df["date"] = pd.to_datetime(df["date"]).dt.date

    df = df[df["close"] >= min_price]
    if min_dollar_volume > 0:
        df = df[df["dollar_volume"] >= min_dollar_volume]
    df = df[df[rank_by].notna()]

    all_dates  = sorted(df["date"].unique())
    next_day   = {d: all_dates[i + 1] for i, d in enumerate(all_dates[:-1])}
    open_lookup = df.set_index(["date", "symbol"])["open"].to_dict()

    results = []
    for date, day_df in df.groupby("date"):
        ranked = (
            day_df[["symbol", "close", "open", "dollar_volume", rank_by]]
            .copy()
            .sort_values(rank_by, ascending=ascending)
            .reset_index(drop=True)
        )
        ranked["rank"]       = ranked.index + 1
        ranked["rank_score"] = ranked[rank_by]

        if entry_price_col == "open":
            trade_date = next_day.get(date)
            if trade_date is None:
                continue
            ranked["entry_price"] = ranked["symbol"].map(
                lambda s: open_lookup.get((trade_date, s))
            )
            ranked["date"] = trade_date
        else:
            ranked["entry_price"] = ranked[entry_price_col]
            ranked["date"]        = date

        top = (ranked[ranked["rank"] <= top_n]
               .dropna(subset=["entry_price"])
               [["date", "symbol", "entry_price", "rank_score", "rank"]])
        results.append(top)

    if not results:
        return pd.DataFrame(columns=["date", "symbol", "entry_price", "rank_score", "rank"])
    return pd.concat(results, ignore_index=True).sort_values(["date", "rank"])


def rank_latest_prior_returns(
    metrics_df: pd.DataFrame,
    trade_date=None,
    rank_by: str = "ret_5d",
    top_n: int = 100,
    min_price: float = 3.0,
    min_dollar_volume: float = 0.0,
    ascending: bool = False,
) -> pd.DataFrame:
    """
    Rank based on the most recent completed trading day in metrics_df.
    Returns rankings tagged with trade_date for immediate live execution at market open.
    """
    if rank_by not in VALID_METRICS:
        raise ValueError(f"rank_by must be one of {VALID_METRICS}")

    df = metrics_df.copy()
    df["date"] = pd.to_datetime(df["date"]).dt.date
    df = df[df["close"] >= min_price]
    if min_dollar_volume > 0:
        df = df[df["dollar_volume"] >= min_dollar_volume]
    df = df[df[rank_by].notna()]

    if df.empty:
        return pd.DataFrame(columns=["date", "symbol", "entry_price", "rank_score", "rank"])

    latest_date = df["date"].max()
    day_df = df[df["date"] == latest_date].copy()
    ranked = day_df.sort_values(rank_by, ascending=ascending).reset_index(drop=True)
    ranked["rank"] = ranked.index + 1
    ranked["rank_score"] = ranked[rank_by]
    ranked["entry_price"] = ranked["close"]
    ranked["date"] = trade_date if trade_date is not None else latest_date

    top = (ranked[ranked["rank"] <= top_n]
           .dropna(subset=["entry_price"])
           [["date", "symbol", "entry_price", "rank_score", "rank"]])
    return top.reset_index(drop=True)


# ── 2. Overnight gap ranking ───────────────────────────────────────────────────

def rank_by_gap(
    metrics_df: pd.DataFrame,
    top_n: int = 100,
    min_price: float = 3.0,
    min_dollar_volume: float = 0.0,
    ascending: bool = False,
) -> pd.DataFrame:
    """
    Rank by overnight gap: (today_open / yesterday_close) - 1

    This is the "extended hours / out-of-market move" signal using only
    free IEX data. The gap fully reflects pre-market and after-hours moves
    because it's the difference between yesterday's close and today's open.

    No lookahead: both prices are known the moment market opens.
    entry_price = today's open (you buy right as market opens on the gap).

    ascending=False -> TOP    (biggest positive gaps first — gapping up)
    ascending=True  -> BOTTOM (biggest negative gaps first — gapping down)
    """
    df = metrics_df.copy()
    df["date"] = pd.to_datetime(df["date"]).dt.date

    df = df[df["close"] >= min_price]
    if min_dollar_volume > 0:
        df = df[df["dollar_volume"] >= min_dollar_volume]

    # gap = open vs previous close (already computed as move_vs_prev_close on open)
    # We compute it directly here for clarity
    df = df.sort_values(["symbol", "date"])
    df["prev_close"] = df.groupby("symbol")["close"].shift(1)
    df["gap_score"]  = (df["open"] / df["prev_close"]) - 1.0
    df = df[df["gap_score"].notna() & (df["prev_close"] > 0)]

    results = []
    for date, day_df in df.groupby("date"):
        ranked = (
            day_df[["symbol", "open", "dollar_volume", "gap_score"]]
            .copy()
            .sort_values("gap_score", ascending=ascending)
            .reset_index(drop=True)
        )
        ranked["rank"]        = ranked.index + 1
        ranked["rank_score"]  = ranked["gap_score"]
        ranked["entry_price"] = ranked["open"]   # buy at open = act on the gap
        ranked["date"]        = date

        top = (ranked[ranked["rank"] <= top_n]
               [["date", "symbol", "entry_price", "rank_score", "rank"]])
        results.append(top)

    if not results:
        return pd.DataFrame(columns=["date", "symbol", "entry_price", "rank_score", "rank"])
    return pd.concat(results, ignore_index=True).sort_values(["date", "rank"])


# ── 3. Intraday move ranking (15-min bars) ─────────────────────────────────────

def rank_by_intraday_move(
    bars_15m: pd.DataFrame,
    entry_bar: str = "15M",
    top_n: int = 100,
    min_price: float = 3.0,
    ascending: bool = False,
) -> pd.DataFrame:
    """
    Rank by intraday move from the day's open to a specific time,
    using 15-minute bars.

    entry_bar options:
      "15M"  -> signal = open-to-9:45  move, entry at 9:45 AM (close of 9:30 bar)
      "30M"  -> signal = open-to-10:00 move, entry at 10:00 AM (close of 9:45 bar)
      "1H"   -> signal = open-to-10:30 move, entry at 10:30 AM (close of 10:15 bar)

    rank_score = (entry_bar_close / day_open) - 1
    entry_price = close of the target bar

    No lookahead: at entry time you know exactly how much the stock moved.
    ascending=False -> TOP    (up most from open)
    ascending=True  -> BOTTOM (down most from open)
    """
    # Which 15-min bar close to use as entry
    bar_map = {
        "15M": (9, 30),    # bar starting 9:30, close = 9:45 AM
        "30M": (9, 45),    # bar starting 9:45, close = 10:00 AM
        "1H":  (10, 15),   # bar starting 10:15, close = 10:30 AM
    }
    if entry_bar not in bar_map:
        raise ValueError(f"entry_bar must be one of {list(bar_map.keys())}")

    target_hour, target_minute = bar_map[entry_bar]

    df = bars_15m.copy()
    df["date"] = pd.to_datetime(df["date"]).dt.date

    # Day open = close of very first bar of the day (9:30 bar open price)
    first_bars = df[(df["hour_et"] == 9) & (df["minute_et"] == 30)][
        ["date", "symbol", "open"]
    ].rename(columns={"open": "day_open"})

    # Target bar
    target_bars = df[
        (df["hour_et"] == target_hour) & (df["minute_et"] == target_minute)
    ][["date", "symbol", "close"]].rename(columns={"close": "entry_price"})

    merged = first_bars.merge(target_bars, on=["date", "symbol"], how="inner")
    merged = merged[merged["day_open"] >= min_price]
    merged = merged[merged["day_open"] > 0]

    merged["rank_score"] = (merged["entry_price"] / merged["day_open"]) - 1.0

    results = []
    for date, day_df in merged.groupby("date"):
        ranked = (
            day_df[["symbol", "entry_price", "rank_score"]]
            .copy()
            .sort_values("rank_score", ascending=ascending)
            .reset_index(drop=True)
        )
        ranked["rank"] = ranked.index + 1
        ranked["date"] = date
        top = ranked[ranked["rank"] <= top_n][
            ["date", "symbol", "entry_price", "rank_score", "rank"]
        ]
        results.append(top)

    if not results:
        return pd.DataFrame(columns=["date", "symbol", "entry_price", "rank_score", "rank"])
    return pd.concat(results, ignore_index=True).sort_values(["date", "rank"])
