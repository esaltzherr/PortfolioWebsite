"""
tracker.py

SQLite persistence layer. Records every order, position, and daily P&L
tagged by strategy. All writes are atomic (BEGIN/COMMIT). Thread-safe via
a module-level lock so live_trader.py can write from multiple points safely.

Tables:
  trades        — every open + close order, one row per leg
  daily_pnl     — EOD snapshot per strategy per day
  daily_equity  — total account equity snapshot per day

Public API:
  init_db()
  record_open(strategy, symbol, direction, shares, price, date, session)
  record_close(strategy, symbol, direction, shares, price, date)
  snapshot_eod(date)          — call after liquidation; computes day P&L
  get_trades(strategy, days)  -> list[dict]
  get_daily_pnl(strategy, days) -> list[dict]
  get_open_positions()        -> list[dict]
  get_summary()               -> list[dict]   — all-time per-strategy
  export_csvs(output_dir)     — dump everything to CSV
"""

import sqlite3
import threading
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import csv
import os

DB_PATH = "trading.db"
ET = ZoneInfo("America/New_York")
_lock = threading.Lock()


def _conn() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA foreign_keys=ON")
    return con


def init_db():
    """Create tables if they don't exist. Safe to call on every startup."""
    with _lock, _conn() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS trades (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy        TEXT    NOT NULL,
            symbol          TEXT    NOT NULL,
            direction       TEXT    NOT NULL,   -- LONG | SHORT
            session         TEXT,               -- OPEN | 15M | 30M
            open_date       TEXT    NOT NULL,
            open_price      REAL    NOT NULL,
            open_shares     REAL    NOT NULL,
            open_value      REAL    NOT NULL,   -- open_shares * open_price
            close_date      TEXT,
            close_price     REAL,
            close_value     REAL,
            pnl_dollars     REAL,
            pnl_pct         REAL,
            status          TEXT    NOT NULL DEFAULT 'OPEN',  -- OPEN | CLOSED
            created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS daily_pnl (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            trade_date      TEXT    NOT NULL,
            strategy        TEXT    NOT NULL,
            n_trades        INTEGER NOT NULL DEFAULT 0,
            n_wins          INTEGER NOT NULL DEFAULT 0,
            n_losses        INTEGER NOT NULL DEFAULT 0,
            gross_pnl       REAL    NOT NULL DEFAULT 0.0,
            win_rate        REAL,
            avg_win         REAL,
            avg_loss        REAL,
            best_trade      REAL,
            worst_trade     REAL,
            capital_deployed REAL,
            created_at      TEXT    NOT NULL DEFAULT (datetime('now')),
            UNIQUE(trade_date, strategy)
        );

        CREATE TABLE IF NOT EXISTS daily_equity (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            trade_date      TEXT    NOT NULL UNIQUE,
            equity_start    REAL,
            equity_end      REAL,
            day_pnl         REAL,
            day_pnl_pct     REAL,
            created_at      TEXT    NOT NULL DEFAULT (datetime('now'))
        );

        CREATE INDEX IF NOT EXISTS idx_trades_strategy ON trades(strategy);
        CREATE INDEX IF NOT EXISTS idx_trades_symbol   ON trades(symbol);
        CREATE INDEX IF NOT EXISTS idx_trades_date     ON trades(open_date);
        CREATE INDEX IF NOT EXISTS idx_daily_date      ON daily_pnl(trade_date);
        """)


# ── Write operations ───────────────────────────────────────────────────────────

def record_open(strategy: str, symbol: str, direction: str,
                shares: float, price: float,
                trade_date: date, session: str = None):
    """Record an opening order (BUY or SHORT_OPEN)."""
    with _lock, _conn() as con:
        con.execute("""
            INSERT INTO trades
                (strategy, symbol, direction, session,
                 open_date, open_price, open_shares, open_value, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'OPEN')
        """, (strategy, symbol, direction, session,
              str(trade_date), price, shares, shares * price))


def record_close(strategy: str, symbol: str, direction: str,
                 shares: float, price: float, trade_date: date):
    """
    Match against the most recent OPEN trade for symbol/direction and record the close.
    Computes P&L and updates the trade to CLOSED.
    """
    with _lock, _conn() as con:
        row = None
        # First attempt: match by exact strategy, symbol, direction
        if strategy and strategy not in ("EOD", "MANUAL", "INTERRUPT"):
            if direction:
                row = con.execute("""
                    SELECT id, strategy, direction, open_price, open_shares, open_value
                    FROM trades
                    WHERE strategy=? AND symbol=? AND direction=? AND status='OPEN'
                    ORDER BY open_date DESC, id DESC
                    LIMIT 1
                """, (strategy, symbol, direction)).fetchone()
            else:
                row = con.execute("""
                    SELECT id, strategy, direction, open_price, open_shares, open_value
                    FROM trades
                    WHERE strategy=? AND symbol=? AND status='OPEN'
                    ORDER BY open_date DESC, id DESC
                    LIMIT 1
                """, (strategy, symbol)).fetchone()

        # Second attempt: match any OPEN trade for this symbol (and direction if provided)
        if row is None:
            if direction:
                row = con.execute("""
                    SELECT id, strategy, direction, open_price, open_shares, open_value
                    FROM trades
                    WHERE symbol=? AND direction=? AND status='OPEN'
                    ORDER BY open_date DESC, id DESC
                    LIMIT 1
                """, (symbol, direction)).fetchone()
            else:
                row = con.execute("""
                    SELECT id, strategy, direction, open_price, open_shares, open_value
                    FROM trades
                    WHERE symbol=? AND status='OPEN'
                    ORDER BY open_date DESC, id DESC
                    LIMIT 1
                """, (symbol,)).fetchone()

        if row is None:
            # No matching open — record as orphan close
            actual_strategy = strategy or "UNKNOWN"
            actual_direction = direction or "LONG"
            con.execute("""
                INSERT INTO trades
                    (strategy, symbol, direction, open_date, open_price,
                     open_shares, open_value, close_date, close_price,
                     close_value, pnl_dollars, pnl_pct, status)
                VALUES (?, ?, ?, ?, 0, ?, 0, ?, ?, ?, 0, 0, 'CLOSED')
            """, (actual_strategy, symbol, actual_direction,
                  str(trade_date), shares,
                  str(trade_date), price, shares * price))
            return

        actual_direction = row["direction"]
        actual_shares = shares if (shares and shares > 0) else row["open_shares"]
        close_value = actual_shares * price
        open_value  = row["open_value"]

        if actual_direction == "LONG":
            pnl_dollars = close_value - open_value
        else:  # SHORT
            pnl_dollars = open_value - close_value

        pnl_pct = (pnl_dollars / open_value * 100.0) if open_value else 0.0

        con.execute("""
            UPDATE trades
            SET close_date=?, close_price=?, close_value=?,
                pnl_dollars=?, pnl_pct=?, status='CLOSED'
            WHERE id=?
        """, (str(trade_date), price, close_value,
              round(pnl_dollars, 4), round(pnl_pct, 4), row["id"]))


def snapshot_eod(trade_date: date, equity_start: float = None,
                 equity_end: float = None):
    """
    Aggregate closed trades for today into daily_pnl.
    Call this after EOD liquidation completes.
    """
    date_str = str(trade_date)
    with _lock, _conn() as con:
        rows = con.execute("""
            SELECT strategy,
                   COUNT(*)                          AS n_trades,
                   SUM(CASE WHEN pnl_dollars > 0 THEN 1 ELSE 0 END) AS n_wins,
                   SUM(CASE WHEN pnl_dollars <= 0 THEN 1 ELSE 0 END) AS n_losses,
                   SUM(pnl_dollars)                  AS gross_pnl,
                   AVG(CASE WHEN pnl_dollars > 0 THEN pnl_dollars END) AS avg_win,
                   AVG(CASE WHEN pnl_dollars <= 0 THEN pnl_dollars END) AS avg_loss,
                   MAX(pnl_dollars)                  AS best_trade,
                   MIN(pnl_dollars)                  AS worst_trade,
                   SUM(open_value)                   AS capital_deployed
            FROM trades
            WHERE close_date=? AND status='CLOSED'
            GROUP BY strategy
        """, (date_str,)).fetchall()

        for r in rows:
            n_trades = r["n_trades"] or 0
            n_wins   = r["n_wins"]   or 0
            win_rate = (n_wins / n_trades * 100.0) if n_trades else None

            con.execute("""
                INSERT INTO daily_pnl
                    (trade_date, strategy, n_trades, n_wins, n_losses,
                     gross_pnl, win_rate, avg_win, avg_loss,
                     best_trade, worst_trade, capital_deployed)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(trade_date, strategy) DO UPDATE SET
                    n_trades=excluded.n_trades,
                    n_wins=excluded.n_wins,
                    n_losses=excluded.n_losses,
                    gross_pnl=excluded.gross_pnl,
                    win_rate=excluded.win_rate,
                    avg_win=excluded.avg_win,
                    avg_loss=excluded.avg_loss,
                    best_trade=excluded.best_trade,
                    worst_trade=excluded.worst_trade,
                    capital_deployed=excluded.capital_deployed
            """, (date_str, r["strategy"], n_trades, n_wins, r["n_losses"],
                  round(r["gross_pnl"] or 0, 4), win_rate,
                  r["avg_win"], r["avg_loss"],
                  r["best_trade"], r["worst_trade"],
                  r["capital_deployed"]))

        # Account-level equity snapshot
        if equity_start is not None or equity_end is not None:
            day_pnl     = (equity_end - equity_start) if (equity_start and equity_end) else None
            day_pnl_pct = (day_pnl / equity_start * 100.0) if (day_pnl and equity_start) else None
            con.execute("""
                INSERT INTO daily_equity
                    (trade_date, equity_start, equity_end, day_pnl, day_pnl_pct)
                VALUES (?,?,?,?,?)
                ON CONFLICT(trade_date) DO UPDATE SET
                    equity_start=excluded.equity_start,
                    equity_end=excluded.equity_end,
                    day_pnl=excluded.day_pnl,
                    day_pnl_pct=excluded.day_pnl_pct
            """, (date_str, equity_start, equity_end,
                  round(day_pnl, 4) if day_pnl else None,
                  round(day_pnl_pct, 4) if day_pnl_pct else None))


# ── Read operations ────────────────────────────────────────────────────────────

def get_trades(strategy: str = None, days: int = 30) -> list[dict]:
    with _lock, _conn() as con:
        if strategy:
            rows = con.execute("""
                SELECT * FROM trades
                WHERE strategy=?
                  AND open_date >= date('now', ? || ' days')
                ORDER BY open_date DESC, id DESC
            """, (strategy, f"-{days}")).fetchall()
        else:
            rows = con.execute("""
                SELECT * FROM trades
                WHERE open_date >= date('now', ? || ' days')
                ORDER BY open_date DESC, id DESC
            """, (f"-{days}",)).fetchall()
        return [dict(r) for r in rows]


def get_daily_pnl(strategy: str = None, days: int = 30) -> list[dict]:
    with _lock, _conn() as con:
        if strategy:
            rows = con.execute("""
                SELECT * FROM daily_pnl
                WHERE strategy=?
                  AND trade_date >= date('now', ? || ' days')
                ORDER BY trade_date DESC
            """, (strategy, f"-{days}")).fetchall()
        else:
            rows = con.execute("""
                SELECT * FROM daily_pnl
                WHERE trade_date >= date('now', ? || ' days')
                ORDER BY trade_date DESC, strategy
            """, (f"-{days}",)).fetchall()
        return [dict(r) for r in rows]


def get_open_positions() -> list[dict]:
    with _lock, _conn() as con:
        rows = con.execute("""
            SELECT * FROM trades WHERE status='OPEN'
            ORDER BY open_date DESC, strategy
        """).fetchall()
        return [dict(r) for r in rows]


def get_daily_equity(days: int = 90) -> list[dict]:
    with _lock, _conn() as con:
        rows = con.execute("""
            SELECT * FROM daily_equity
            WHERE trade_date >= date('now', ? || ' days')
            ORDER BY trade_date DESC
        """, (f"-{days}",)).fetchall()
        return [dict(r) for r in rows]


def get_summary() -> list[dict]:
    """All-time per-strategy summary."""
    with _lock, _conn() as con:
        rows = con.execute("""
            SELECT
                strategy,
                COUNT(*)                                    AS total_trades,
                SUM(CASE WHEN pnl_dollars > 0 THEN 1 END)  AS total_wins,
                SUM(CASE WHEN pnl_dollars <= 0 THEN 1 END) AS total_losses,
                SUM(pnl_dollars)                            AS total_pnl,
                AVG(pnl_pct)                                AS avg_pnl_pct,
                MAX(pnl_dollars)                            AS best_trade,
                MIN(pnl_dollars)                            AS worst_trade,
                SUM(open_value)                             AS total_deployed,
                MIN(open_date)                              AS first_trade_date,
                MAX(open_date)                              AS last_trade_date
            FROM trades
            WHERE status='CLOSED'
            GROUP BY strategy
            ORDER BY total_pnl DESC
        """).fetchall()
        results = []
        for r in rows:
            d = dict(r)
            total = d["total_trades"] or 0
            wins  = d["total_wins"]  or 0
            d["win_rate_pct"] = round(wins / total * 100, 1) if total else 0
            d["total_pnl"]    = round(d["total_pnl"] or 0, 2)
            results.append(d)
        return results


def export_csvs(output_dir: str = "exports"):
    """Dump all tables to CSV files."""
    os.makedirs(output_dir, exist_ok=True)
    with _lock, _conn() as con:
        for table in ("trades", "daily_pnl", "daily_equity"):
            rows = con.execute(f"SELECT * FROM {table}").fetchall()
            if not rows:
                continue
            path = os.path.join(output_dir, f"{table}.csv")
            with open(path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows([dict(r) for r in rows])
    return output_dir